module com.rather.capital_school_beta {
    requires javafx.controls;
    requires javafx.fxml;
    requires lombok;
    requires unirest.java;
    requires java.desktop;
    requires org.json;
    requires service;
    requires api;

    opens com.rather.capital_school_beta to javafx.fxml;
    exports com.rather.capital_school_beta;
    exports com.rather.capital_school_beta.Controllers;
    opens com.rather.capital_school_beta.Controllers to javafx.fxml;
}