package com.rather.capital_school_beta.Controllers;

import com.rather.capital_school_beta.GenerationAI.ImageGenerator;
import com.rather.capital_school_beta.Quiz.Question;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.scene.shape.QuadCurve;
import javafx.scene.text.Font;
import javafx.stage.Popup;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.Window;
import javax.imageio.ImageIO;

public class MainController {
    //---------------------------------------------------------------------------------------------------------
    private Scene scene;
    private Stage stage;
    @FXML
    private AnchorPane main_AnchorPane;
    //---------------------------------------------------------------------------------------------------------
    @FXML
    private ImageView AI_ImageView;
    @FXML
    private Label question_Label;
    @FXML
    private Button changeImage_Button;
    //---------------------------------------------------------------------------------------------------------
    @FXML
    private Button answer0_Button;
    @FXML
    private Button answer1_Button;
    @FXML
    private Button answer2_Button;
    @FXML
    private Button answer3_Button;
    @FXML
    private Button answer4_Button;
    @FXML
    private Button answer5_Button;
    @FXML
    private Button answer6_Button;
    @FXML
    private Button answer7_Button;
    //---------------------------------------------------------------------------------------------------------
    private int numberOfQuestion = 0;
    private int numberOfAttempt = 0;
    private int result = 0;
    //---------------------------------------------------------------------------------------------------------

    private VBox resultsMain_VBox;
    private VBox results_VBox;
    private Label congratulation_Label;
    private Label results_Label;
    private Button restartQuiz_Button;

    private Popup results_Popup;
    private double anchorXPopupResults;
    private double anchorYPopupResults;

    private final int HeightPopupResults = 350;
    private final int WidthPopupResults = 500;

    //---------------------------------------------------------------------------------------------------------

    private static Question[] questions = {
            new Question(
                    "Which singer is in the picture?",
                    new String[]{"BTS", "Arash", "Eminem", "Adele", "BlackPink", "Sia", "Skillet", "Akcent"},0
            ),
            new Question(
                    "Which song is depicted?",
                    new String[]{"Bones", "I'm Alone", "Heat Waves", "A Day in the Life", "Sail to the Moon", "Be My Baby", "Insanity", "Blinding Lights"},7
            ),
            new Question(
                    "What genre of music is commonly associated with the image above?",
                    new String[]{"Jazz", "Reggae", "Pop", "Country", "Hip-hop", "Rock", "Classical", "Blues"},4
            ),
            new Question(
                    "What type of instrument is shown in the image above?",
                    new String[]{"Viola", "Violin", "Cello", "Double bass", "Harp", "Flute", "Clarinet", "Oboe"},6
            ),
            new Question(
                    "What genre of music is commonly associated with the image above?",
                    new String[]{"Heavy metal", "Opera", "R&B", "Electronic dance music (EDM)", "Folk", "Reggaeton", "Soul", "Punk rock"},1
            ),
            new Question(
                    "Which song is depicted?",
                    new String[]{"Feed Good", "Breaking Me", "Wasted", "Frozen", "Bad Boys", "Starboy", "Without Me", "The Monster"},4
            ),
            new Question(
                    "What type of instrument is shown in the image above?",
                    new String[]{"Harp", "Double bass", "Clarinet", "Oboe", "Viola", "Flute", "Cello", "Violin"},6
            ),
            new Question(
                    "Which singer is in the picture?",
                    new String[]{"Mozart", "Imagine Dragons", "Tom Jones", "Crazy frog", "Katy Perry", "Oliver Tree", "Ice Mc", "Sade"},1
            ),
            new Question(
                    "What genre of music is commonly associated with the image above?",
                    new String[]{"Jazz", "Reggae", "Pop", "Country", "Hip-hop", "Rock", "Classical", "Blues"},3
            ),
            new Question(
                    "What type of instrument is shown in the image above?",
                    new String[]{"Cello", "Double bass", "Clarinet", "Violin", "Viola", "Flute", "Oboe", "Harp"},7
            )
    };

    private void createFinalPopup(){
        //stage = Application.getPrimaryStage();
        stage = (Stage) question_Label.getScene().getWindow();
        Window window = question_Label.getScene().getWindow();

        // Определить координаты верхнего левого угла главного окна
        double mainX = stage.getX();
        double mainY = stage.getY();

        // Определить размер главного окна
        double mainWidth = stage.getWidth();
        double mainHeight = stage.getHeight();

        // Определить размер экрана
        Rectangle2D screenBounds = Screen.getPrimary().getBounds();
        double screenWidth = screenBounds.getWidth();
        double screenHeight = screenBounds.getHeight();

        results_Popup.xProperty().add(stage.xProperty().add(mainWidth));
        results_Popup.yProperty().add(stage.yProperty());

        anchorXPopupResults = stage.getX() + (mainWidth - HeightPopupResults*(2.5));
        anchorYPopupResults = stage.getY() + (mainHeight - WidthPopupResults*(1.5));

        // Добавляем слушателя позиции главного окна
        window.xProperty().addListener((observable, oldValue, newValue) -> {
            double x = stage.getX() + (mainWidth - HeightPopupResults*(2.5));
            double y = stage.getY() + (mainHeight - WidthPopupResults*(1.5));
            results_Popup.setX(x);
            results_Popup.setY(y);
        });

        results_Label.setText(
                "The percentage of correctness is " + result*10 + "%\n\n" +
                result + "out of 10 are correct"
        );

        results_Popup.show(stage, anchorXPopupResults, anchorYPopupResults);

        main_AnchorPane.setDisable(true);

        restartQuiz_Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                numberOfQuestion = 0;
                result = 0;
                results_Popup.hide();
                main_AnchorPane.setDisable(false);
                setQuestion();
            }
        });
    }

    private void handlerQuizAnswer(int numButton){
        if(numberOfQuestion<10){
            if (numButton==questions[numberOfQuestion].getIndexOfRightAnswer())
                switch (numberOfAttempt) {
                    case 0: {
                        result = result + 3;
                    }
                    case 1: {
                        result = result + 2;
                    }
                    case 2: {
                        result = result + 1;
                    }
                }
            numberOfQuestion++;
        } else {
            createFinalPopup();
        }
    }

    private void setQuestion(){
        if(numberOfQuestion<10) {
            numberOfAttempt = 0;

            question_Label.setText("\t" + questions[numberOfQuestion].getQuestion());
            answer0_Button.setText(questions[numberOfQuestion].getAnswers()[0]);
            answer1_Button.setText(questions[numberOfQuestion].getAnswers()[1]);
            answer2_Button.setText(questions[numberOfQuestion].getAnswers()[2]);
            answer3_Button.setText(questions[numberOfQuestion].getAnswers()[3]);
            answer4_Button.setText(questions[numberOfQuestion].getAnswers()[4]);
            answer5_Button.setText(questions[numberOfQuestion].getAnswers()[5]);
            answer6_Button.setText(questions[numberOfQuestion].getAnswers()[6]);
            answer7_Button.setText(questions[numberOfQuestion].getAnswers()[7]);

            switch (numberOfQuestion){
                case 0:{
                    AI_ImageView.setImage(new Image("https://media.discordapp.net/attachments/804217427880968202/1112717137509875774/1.2.png"));
                    break;
                }
                case 1:{
                    //AI_ImageView.setImage(new Image("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-H6i9PoPHwawHWeZJtSHW0DPN.png?st=2023-05-28T12%3A05%3A53Z&se=2023-05-28T14%3A05%3A53Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T09%3A59%3A32Z&ske=2023-05-29T09%3A59%3A32Z&sks=b&skv=2021-08-06&sig=hflK2Be%2BvV3fh9zj9OwpVt0seu168xtApMc8/snEvGE%3D"));
                    break;
                }
                case 2:{
                    //AI_ImageView.setImage(new Image("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-wmZchjBEaNZWxqZEMc0AZah2.png?st=2023-05-28T12%3A10%3A24Z&se=2023-05-28T14%3A10%3A24Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T10%3A23%3A47Z&ske=2023-05-29T10%3A23%3A47Z&sks=b&skv=2021-08-06&sig=CvbJCGUBNng7NK%2B4gGMu9IWJ6GU5pGZT6eI7T6nnyM8%3D"));
                    break;
                }
                case 3:{
                    //AI_ImageView.setImage(new Image("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-LyhCS1VndjGdCKaqfAa3aZD6.png?st=2023-05-28T12%3A11%3A42Z&se=2023-05-28T14%3A11%3A42Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T09%3A00%3A29Z&ske=2023-05-29T09%3A00%3A29Z&sks=b&skv=2021-08-06&sig=z7Uh3uPFTQCZAzNDkrAWhr3afvCYyTc%2BkjoRHUVJxB8%3D"));
                    break;
                }
                case 4:{
                    //AI_ImageView.setImage(new Image("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-Q3a0sIDXOqHBYJTWl2WzJbOQ.png?st=2023-05-28T12%3A13%3A03Z&se=2023-05-28T14%3A13%3A03Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-27T21%3A40%3A49Z&ske=2023-05-28T21%3A40%3A49Z&sks=b&skv=2021-08-06&sig=Vh/bCp9uavR5o56UDYkawuTLRtCM7WZKscWBZe5LMrY%3D"));
                    break;
                }
                case 5:{
                    //AI_ImageView.setImage(new Image("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-yohLQLcs41inxMAU1u9Tv8gf.png?st=2023-05-28T12%3A18%3A33Z&se=2023-05-28T14%3A18%3A33Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-27T22%3A32%3A09Z&ske=2023-05-28T22%3A32%3A09Z&sks=b&skv=2021-08-06&sig=8AAo3QNKjDEzIXQbjsMnr64Z0x2BaJE0xnB0xJSq2u0%3D"));
                    break;
                }
                case 6:{
                    //AI_ImageView.setImage(new Image("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-hok4VKNDOsivnu4RcoutIEcx.png?st=2023-05-28T12%3A20%3A39Z&se=2023-05-28T14%3A20%3A39Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T04%3A54%3A16Z&ske=2023-05-29T04%3A54%3A16Z&sks=b&skv=2021-08-06&sig=wFNAKWQaNscYjZVXdH5uuySUSxi8M6sv9HY8gTnFmDs%3D"));
                    break;
                }
                case 7:{
                    //AI_ImageView.setImage(new Image("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-oNFxyVAKXKsGANzNw0fk75bT.png?st=2023-05-28T12%3A22%3A28Z&se=2023-05-28T14%3A22%3A28Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T00%3A46%3A03Z&ske=2023-05-29T00%3A46%3A03Z&sks=b&skv=2021-08-06&sig=0RJ7wtwZ78aK7ldo4/AVD/%2B8le5Ht7TfHGJXHLXfMDE%3D"));
                    break;
                }
                case 8:{
                    AI_ImageView.setImage(new Image("https://media.discordapp.net/attachments/804217427880968202/1112717319530102834/9.1.png"));
                    break;
                }
                case 9:{
                    AI_ImageView.setImage(new Image("https://media.discordapp.net/attachments/804217427880968202/1112717318460555285/10.1.png"));
                    break;
                }
            }
        } else {
            createFinalPopup();
        }
    }

    private void setActionsButtons(){
        answer0_Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                handlerQuizAnswer(0);
                setQuestion();
            }
        });
        answer1_Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                handlerQuizAnswer(1);
                setQuestion();
            }
        });
        answer2_Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                handlerQuizAnswer(2);
                setQuestion();
            }
        });
        answer3_Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                handlerQuizAnswer(3);
                setQuestion();
            }
        });
        answer4_Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                handlerQuizAnswer(4);
                setQuestion();
            }
        });
        answer5_Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                handlerQuizAnswer(5);
                setQuestion();
            }
        });
        answer6_Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                handlerQuizAnswer(6);
                setQuestion();
            }
        });
        answer7_Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                handlerQuizAnswer(7);
                setQuestion();
            }
        });
    }


    @FXML
    public void initialize() {
        //---------------------------------------------------------------------------------------------------------
        // Настройка компонентов всплывающего окна результатов.
        results_Label = new Label();
        results_Label.setStyle("-fx-background-color: #382F85; -fx-border-color: #ffffff;");
        results_Label.setPrefSize(WidthPopupResults-60, HeightPopupResults-120);
        results_Label.setAlignment(Pos.CENTER);
        results_Label.setTextFill(Paint.valueOf("#ffffff"));
        results_Label.setFont(new Font("Agency FB", 18));

        congratulation_Label = new Label("Congratulation!");
        congratulation_Label.setStyle("-fx-background-color: #A66500; -fx-border-color: #ffffff;");
        congratulation_Label.setTextFill(Paint.valueOf("#ffffff"));
        congratulation_Label.setAlignment(Pos.CENTER);
        congratulation_Label.setFont(new Font("Agency FB", 20));
        congratulation_Label.setPrefSize(WidthPopupResults-60, HeightPopupResults-300);

        results_VBox = new VBox();
        results_VBox.setPrefSize(WidthPopupResults-60, HeightPopupResults-60);
        results_VBox.setAlignment(Pos.CENTER);
        results_VBox.getChildren().add(congratulation_Label);
        results_VBox.getChildren().add(results_Label);

        restartQuiz_Button = new Button("Restart");
        restartQuiz_Button.setTextFill(Paint.valueOf("#ffffff"));
        restartQuiz_Button.setFont(new Font("Agency FB", 20));
        restartQuiz_Button.setStyle("-fx-background-color: #FF9C00; -fx-border-color: #ffffff; -fx-border-width: 3; -fx-border-radius: 10; -fx-background-radius: 10;");

        resultsMain_VBox = new VBox();
        resultsMain_VBox.setStyle("-fx-border-color: #ffffff; -fx-background-color: #228751;");
        resultsMain_VBox.setSpacing(20);
        resultsMain_VBox.setPrefSize(WidthPopupResults, HeightPopupResults);
        resultsMain_VBox.setAlignment(Pos.CENTER);
        resultsMain_VBox.setPadding(new Insets(30));
        resultsMain_VBox.getChildren().add(results_VBox);
        resultsMain_VBox.getChildren().add(restartQuiz_Button);

        results_Popup = new Popup();
        results_Popup.getContent().add(resultsMain_VBox);
        results_Popup.setHeight(HeightPopupResults);
        results_Popup.setWidth(WidthPopupResults);
        //---------------------------------------------------------------------------------------------------------

        changeImage_Button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                changeImageAIInterface aiInterface = new changeImageAIInterface() {
                    public void setImageAI(String firstRef, String secondRef) {
                        if (numberOfAttempt==1)
                            AI_ImageView.setImage(new Image(firstRef));
                        else
                            AI_ImageView.setImage(new Image(secondRef));
                    };
                };

                if(numberOfAttempt<3) {
                    numberOfAttempt++;

                    switch (numberOfQuestion){
                        case 0:{
                            aiInterface.setImageAI("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-bIh0jOZr5mb2FYTOStB6XR60.png?st=2023-05-28T10%3A23%3A48Z&se=2023-05-28T12%3A23%3A48Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T10%3A51%3A45Z&ske=2023-05-29T10%3A51%3A45Z&sks=b&skv=2021-08-06&sig=8oVltHPmwcoCsBFo5sZ3PJpf5AMCriwEQ0ghSXFp0uw%3D", "https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-qnjUcZa7j5Bxy65bXOEOQi6c.png?st=2023-05-28T10%3A24%3A07Z&se=2023-05-28T12%3A24%3A07Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T10%3A34%3A32Z&ske=2023-05-29T10%3A34%3A32Z&sks=b&skv=2021-08-06&sig=4oqG4bxnaKG4UGbwL7AyMfKgVRiXgWHTckpL0rAviBY%3D");
                        }
                        case 1:{
                            aiInterface.setImageAI("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-iqjCuZrZsvQvFTpIfp1RR2MA.png?st=2023-05-28T12%3A07%3A58Z&se=2023-05-28T14%3A07%3A58Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T09%3A02%3A31Z&ske=2023-05-29T09%3A02%3A31Z&sks=b&skv=2021-08-06&sig=N2pW75uVpCmZICCaXpoRkm1kR85C4Qi47tAzBEIHnn8%3D", "https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-7DQxaSFIhYGcNiUCG2QW6Tc5.png?st=2023-05-28T12%3A08%3A18Z&se=2023-05-28T14%3A08%3A18Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T08%3A57%3A29Z&ske=2023-05-29T08%3A57%3A29Z&sks=b&skv=2021-08-06&sig=onZxQIO1vx5tCZb1f%2BzBnDO%2Bg63g5JyVQ/disM3YLio%3D");
                        }
                        case 2:{
                            aiInterface.setImageAI("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-aRsYzN3IrlJLz0qS23XevEtS.png?st=2023-05-28T12%3A10%3A45Z&se=2023-05-28T14%3A10%3A45Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-27T23%3A44%3A34Z&ske=2023-05-28T23%3A44%3A34Z&sks=b&skv=2021-08-06&sig=XY0CXn9TVu43X60KM3dnG0WYy1tQTH4ffNvnX%2BBMRxQ%3D", "https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-rAnEsBgjHr76oVoR0mfSC9Kd.png?st=2023-05-28T12%3A11%3A00Z&se=2023-05-28T14%3A11%3A00Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T08%3A14%3A42Z&ske=2023-05-29T08%3A14%3A42Z&sks=b&skv=2021-08-06&sig=p6Jh8q9NN6FpW3GNl1JYlwN32zU7yPIPyyqXlu4D8%2BU%3D");
                        }
                        case 3:{
                            aiInterface.setImageAI("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-lzpd4nGwSIQDqAZbMCIHuPnF.png?st=2023-05-28T12%3A12%3A05Z&se=2023-05-28T14%3A12%3A05Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-27T13%3A57%3A47Z&ske=2023-05-28T13%3A57%3A47Z&sks=b&skv=2021-08-06&sig=jioYNsTWBsYMZOPsFVBpLJ1pGqk%2BZbyXH2CAhMSkBes%3D", "https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-wAfNzaumF6DzCI0KrPpQoRg3.png?st=2023-05-28T12%3A12%3A21Z&se=2023-05-28T14%3A12%3A21Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-27T23%3A49%3A06Z&ske=2023-05-28T23%3A49%3A06Z&sks=b&skv=2021-08-06&sig=NZyUvMQ8Uth8hcDSjamPJu4WFtQmo3D/wmL0RS6nrH0%3D");
                        }
                        case 4:{
                            aiInterface.setImageAI("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-ewxyMNQzT4XHLyF8QfHcBixn.png?st=2023-05-28T12%3A13%3A20Z&se=2023-05-28T14%3A13%3A20Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T12%3A54%3A01Z&ske=2023-05-29T12%3A54%3A01Z&sks=b&skv=2021-08-06&sig=sHaRL91u9GRSrH3QK6DixhwRlmqtAmXkGfVsDyEMr8M%3D", "https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-byQt8MLqoVyswUkqCAsthzVk.png?st=2023-05-28T12%3A15%3A16Z&se=2023-05-28T14%3A15%3A16Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T07%3A46%3A12Z&ske=2023-05-29T07%3A46%3A12Z&sks=b&skv=2021-08-06&sig=T5/XDfe%2BRGnbWHoA1akqox68ezxkWM8SOrz30ge6ahk%3D");
                        }
                        case 5:{
                            aiInterface.setImageAI("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-S5CwOzQs1QeFtNTkTErHXtu8.png?st=2023-05-28T12%3A19%3A00Z&se=2023-05-28T14%3A19%3A00Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T09%3A56%3A52Z&ske=2023-05-29T09%3A56%3A52Z&sks=b&skv=2021-08-06&sig=716GkzaJsJTcV9%2Be1G1qeWUdatCxI%2Bbs64IUtVWnaDs%3D", "https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-GB2JNAAuQeSQexWbQZ9npwJ7.png?st=2023-05-28T12%3A19%3A27Z&se=2023-05-28T14%3A19%3A27Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T09%3A24%3A13Z&ske=2023-05-29T09%3A24%3A13Z&sks=b&skv=2021-08-06&sig=nL6Ekoj98O2Mq7NsbEBrwDf5%2BJZRIsvBX4JRtgxYTjo%3D");
                        }
                        case 6:{
                            aiInterface.setImageAI("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-9g8Jl9RH7saX7Fk12rVVZAC7.png?st=2023-05-28T12%3A20%3A59Z&se=2023-05-28T14%3A20%3A59Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T08%3A55%3A12Z&ske=2023-05-29T08%3A55%3A12Z&sks=b&skv=2021-08-06&sig=5FdFQREdN5FArnsK6k8jOp1/guPInZNzGeoxz1ObUjo%3D", "https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-giIyJrHDcXEK6iI8XV3kCpN5.png?st=2023-05-28T12%3A21%3A41Z&se=2023-05-28T14%3A21%3A41Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T02%3A05%3A51Z&ske=2023-05-29T02%3A05%3A51Z&sks=b&skv=2021-08-06&sig=gcfDWPg3KIMXsIMqpiMwa65lM//zqDghZrS2kcLZzmI%3D");
                        }
                        case 7:{
                            aiInterface.setImageAI("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-Jz5RpFuQyx6sU5HWPy5Noq0P.png?st=2023-05-28T12%3A22%3A44Z&se=2023-05-28T14%3A22%3A44Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T00%3A18%3A21Z&ske=2023-05-29T00%3A18%3A21Z&sks=b&skv=2021-08-06&sig=UGD7LK4OzLJEJsBc/%2BPd/hISTPFX1gJ0GJiFnsOsnrs%3D", "https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-4F0AZ5C6zYeOMgDXeGkY3JCB.png?st=2023-05-28T12%3A23%3A04Z&se=2023-05-28T14%3A23%3A04Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-28T05%3A48%3A31Z&ske=2023-05-29T05%3A48%3A31Z&sks=b&skv=2021-08-06&sig=kTQGtQObf/hiGE70Hwg92isWrpibS0GiCa3ebatJmQA%3D");
                        }
                        case 8:{
                            aiInterface.setImageAI("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-ZE8RkIyY5nwJyR7DMoQrqxpZ.png?st=2023-05-29T09%3A11%3A43Z&se=2023-05-29T11%3A11%3A43Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-29T05%3A05%3A30Z&ske=2023-05-30T05%3A05%3A30Z&sks=b&skv=2021-08-06&sig=nNhM59DIY5cP9McNS2XET7SupcAShC91U/ultVVu4hc%3D\n", "https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-2giI1cA3d02PrHUQ3zp4KNNM.png?st=2023-05-29T09%3A12%3A15Z&se=2023-05-29T11%3A12%3A15Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-29T03%3A28%3A00Z&ske=2023-05-30T03%3A28%3A00Z&sks=b&skv=2021-08-06&sig=RtmrZfqlNc5Ltt/WTT41B0W3YyKYQ/Np7g6Pax8MujE%3D");
                        }
                        case 9:{
                            aiInterface.setImageAI("https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-IUF4VtPFCyMwgP6GzzseNkE7.png?st=2023-05-29T09%3A16%3A52Z&se=2023-05-29T11%3A16%3A52Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-29T07%3A25%3A22Z&ske=2023-05-30T07%3A25%3A22Z&sks=b&skv=2021-08-06&sig=WjLRQfbDDzWFx6w1OG52hwsARy0V2aPAR5x3/Y0qsWI%3D", "https://oaidalleapiprodscus.blob.core.windows.net/private/org-MPSoWtF0zg9TheYgbl0qRaeR/user-mAQ50ILy1UrSgBq72NTZz4yF/img-VroXOwbUl7YcaCHONH3Qgsfu.png?st=2023-05-29T09%3A17%3A16Z&se=2023-05-29T11%3A17%3A16Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2023-05-29T07%3A58%3A58Z&ske=2023-05-30T07%3A58%3A58Z&sks=b&skv=2021-08-06&sig=I3OG6Vo6K7tv8eIt0HmnfyWoO4A7f3JvLMTS4iUuViE%3D\n");
                        }
                    }
                }
            }
        });

        //---------------------------------------------------------------------------------------------------------

        setActionsButtons();
        setQuestion();
    }

    interface changeImageAIInterface {
        void setImageAI(String firstRef, String secondRef);
    }

}