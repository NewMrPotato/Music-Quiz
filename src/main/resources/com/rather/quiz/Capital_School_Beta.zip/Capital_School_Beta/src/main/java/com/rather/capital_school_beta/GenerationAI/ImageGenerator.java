package com.rather.capital_school_beta.GenerationAI;


import com.mashape.unirest.http.ObjectMapper;
import com.theokanning.openai.completion.CompletionRequest;
import com.theokanning.openai.service.OpenAiService;

import static com.theokanning.openai.service.OpenAiService.defaultClient;
import static com.theokanning.openai.service.OpenAiService.defaultObjectMapper;

public class ImageGenerator {
    public String generateImage(){
        try {
            // Set the API endpoint and parameters
            String endpoint = "https://api.openai.com/v1/images/generations";
            String apiKey = "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";
            String prompt = "A cat sitting on a piano";
            int numImages = 1;
            int size = 512;
            double temperature = 0.5;
            int topP = 1;
            int seed = 42;
            boolean openaiOrg = false;

        } catch (Exception e) {
        }

        return null;
    }
}
