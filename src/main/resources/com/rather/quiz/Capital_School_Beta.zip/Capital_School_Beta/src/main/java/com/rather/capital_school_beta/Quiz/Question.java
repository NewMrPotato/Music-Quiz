package com.rather.capital_school_beta.Quiz;

import lombok.*;

@Getter@Setter
public class Question {
    private String question;
    private String[] answers;
    private int indexOfRightAnswer;
    private String prompt;

    public Question(String question, String[] answers, int indexOfRightAnswer) {
        this.question = question;
        this.answers = answers;
        this.indexOfRightAnswer = indexOfRightAnswer;
    }

    public Question(String question, String[] answers, int indexOfRightAnswer, String prompt) {
        this.question = question;
        this.answers = answers;
        this.indexOfRightAnswer = indexOfRightAnswer;
        this.prompt = prompt;
    }
}
